package com.autogeneral.api.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.autogeneral.api.model.ToDoItem;

/**
 * ToDoItemRepository - is the interface which use spring data JPA and extends
 * JpaRepository to execute database queries
 * 
 * @author Bindhya Maya
 * Version 1.0
 * Created Date 02/10/2018
 *
 */
@Repository
public interface ToDoItemRepository extends JpaRepository<ToDoItem,Long> {

}
