package com.autogeneral.api.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Size;


@Entity
@Table(name = "TODO_Item")
public class ToDoItem {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "todo_item_seq")
	@SequenceGenerator(name = "todo_item_seq", sequenceName = "TODO_SEQUENCE", allocationSize = 50)
	private Long id;
	
	@Column(name = "text")
	@Size(min = 1, max = 50, message="text must be between 1 and 50 chars long")
	String text;
	
	@Column(name = "isCompleted")
	boolean isCompleted;
	
	@Column(name = "createdAt")
	String createdAt;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public boolean isCompleted() {
		return isCompleted;
	}
	public void setCompleted(boolean isCompleted) {
		this.isCompleted = isCompleted;
	}
	public String getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

}
