package com.autogeneral.api.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.autogeneral.api.bo.AutoGeneralBO;
import com.autogeneral.api.model.ToDoItem;
import com.autogeneral.api.service.AutoGeneralService;

/**
 * AutoGeneralServiceImpl - This class acts as a service class and all 
 * the method calls coming from Controller will redirect to Business layer to fetch or set the data.
 * 
 * @author Bindhya Maya
 * Version 1.0
 * Created Date 02/10/2018
 */

@Service("autoGeneralService")
public class AutoGeneralServiceImpl implements AutoGeneralService {

	@Autowired
	AutoGeneralBO autoGeneralBO;

	/**
	 * createToDoItem - creates a ToDoItem
	 * 
	 * @param ToDoItem
	 * @return ToDoItem
	 */
	@Override
	public ToDoItem createToDoItem(ToDoItem toDoItem)  throws Exception{
		return autoGeneralBO.createToDoItem(toDoItem);
	}
	
	/**
	 * viewToDoItem - View a particular ToDoItem 
	 * 
	 * @param id
	 * @return ToDoItem
	 */
	@Override
	public ToDoItem viewToDoItem(Long id) throws Exception{
		return autoGeneralBO.viewToDoItem(id);
	}

	/**
	 * editToDoItem - edit a ToDoItem
	 * 
	 * @param id
	 * @return ToDoItem
	 */
	@Override
	public ToDoItem editToDoItem(Long id) throws Exception{
		return autoGeneralBO.editToDoItem(id);
	}

	/**
	 * validateBrackets method determine if a string of bracket is valid or invalid
	 * 	Every opening bracket has a corresponding closing bracket.
	 * 	The closing bracket of a pair must be of the same as the opening bracket, e.g. () is valid, but [) is not valid.
	 * @param inputString
	 * @return String
	 * @throws Exception
	 */	 
	@Override
	public String validateBrackets(String inputString) throws Exception {
		return autoGeneralBO.validateBrackets(inputString);
	}

}
