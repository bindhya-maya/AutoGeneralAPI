package com.autogeneral.api.controller;

import javax.validation.constraints.Size;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.autogeneral.api.service.AutoGeneralService;

/**
 * AutoGeneralTaskController - This class acts as a controller and all the incoming rest
 * endpoints would hit this initially. This class may be redirected to
 * respective services to fetch or set the data.
 * 
 * @author Bindhya Maya
 * Version 1.0
 * Created Date 02/10/2018
 */

@RestController
@RequestMapping("/tasks")
@Validated
public class AutoGeneralTaskController {
	private static final Logger logger = LoggerFactory.getLogger(AutoGeneralTaskController.class);

	@Autowired
	AutoGeneralService autoGeneralService;

	
	/**
	 * validateBrackets method determine if a string of bracket is valid or invalid
	 * 	Every opening bracket has a corresponding closing bracket.
	 * 	The closing bracket of a pair must be of the same as the opening bracket, e.g. () is valid, but [) is not valid.
	 * @param inputString
	 * @return Boolean
	 * @throws Exception
	 */	 
	@GetMapping(value = "/validateBrackets", produces=MediaType.APPLICATION_JSON_VALUE)
	public String validateBrackets(@RequestParam @Size(min= 1, max = 50, message = "inputString length must be between 1 and 50") String inputString) throws Exception {

		logger.info("validateBrackets service called!!!-----------");
		String isInputStringValid = autoGeneralService.validateBrackets(inputString);
		
		logger.info("validateBrackets service called successfully!!!-----------");
		return isInputStringValid;
	}

}
