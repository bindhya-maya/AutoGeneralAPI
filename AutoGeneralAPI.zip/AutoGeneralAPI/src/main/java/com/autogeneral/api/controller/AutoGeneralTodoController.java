package com.autogeneral.api.controller;

import java.util.stream.Collectors;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.annotation.RequestScope;

import com.autogeneral.api.model.AjaxResponseBody;
import com.autogeneral.api.model.ToDoItem;
import com.autogeneral.api.service.AutoGeneralService;

/**
 * AutoGeneralTodoController - This class acts as a controller and all the incoming rest
 * endpoints would hit this initially. This class may be redirected to
 * respective services to fetch or set the data.
 * 
 * @author Bindhya Maya
 * Version 1.0
 * Created Date 02/10/2018
 */

@RestController
@RequestMapping("/todo")
@RequestScope
public class AutoGeneralTodoController {
	private static final Logger logger = LoggerFactory.getLogger(AutoGeneralTodoController.class);

	@Autowired
	AutoGeneralService autoGeneralService;

	/**
	 * createToDoItem - This method contains a rest resource endpoint which is fired
	 * from the client when a new ToDo creation request comes. It creates a new
	 * ToDo based on the parameters provided in the request.
	 *
	 * @param ToDoItem
	 *            request object containing new ToDo details
	 * @return : ResponseEntity<AjaxResponseBody>
	 */
	@RequestMapping(method = RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AjaxResponseBody> createToDoItem(@Valid @RequestBody ToDoItem toDoItem, Errors errors) throws Exception {
		
		AjaxResponseBody  result = new AjaxResponseBody ();

        //If error, just return a 400 bad request, along with the error message
        if (errors.hasErrors()) {

			// get all errors 
            result.setMsg(errors.getAllErrors()
				.stream()
				.map(x -> x.getDefaultMessage())
				.collect(Collectors.joining(",")));
				
            return ResponseEntity.badRequest().body(result);

        }

		logger.info("Create TODO Item service called!!!--------------");
		// create new ToDOItem
		ToDoItem toDoItemResponse = autoGeneralService.createToDoItem(toDoItem);
		result.setResult(toDoItemResponse);
		return ResponseEntity.ok(result);
	}
	

	/**
	 * viewToDoItem - This method contains a rest resource endpoint which
	 * is fired from the client when its required to see a particular ToDoItem 
	 * 
	 * @param ToDoItem
	 *            request object containing ToDoItem details
	 * @return : ResponseEntity<AjaxResponseBody>
	 */
	@RequestMapping(method = RequestMethod.GET)
	public ResponseEntity<AjaxResponseBody> viewToDoItem(@RequestParam("id") Long id) throws Exception {
		ToDoItem toDoItemResponse = null;
		
		logger.info("viewToDoItem service called!!!-----------");
		toDoItemResponse = autoGeneralService
				.viewToDoItem(id);
		
		AjaxResponseBody  result = new AjaxResponseBody ();

        //If error, just return a 404 Not Found, along with the error message
        if (toDoItemResponse == null) {

			// get all errors           	
           /* return ResponseEntity
            .status(HttpStatus.NOT_FOUND)
            .body("{\n message: Item with ID - " + id + " not found \n }");*/
            //return ResponseEntity.notFound(result);
        	return ResponseEntity.notFound().build();
        }
		
		logger.info("viewToDoItem service called successfully!!!-----------");
		result.setResult(toDoItemResponse);
		return ResponseEntity.ok(result);
	}

	/**
	 * editToDoItem - This method contains a rest resource endpoint which is fired
	 * from the client when its required to edit  ToDoItem. 
	 *
	 * @param id
	 *            request object containing todoIdentifier
	 * @return : ResponseEntity<AjaxResponseBody>
	 */
	@RequestMapping(method = RequestMethod.PUT)
	public ResponseEntity<AjaxResponseBody> editToDoItem(@RequestParam("id") Long id) throws Exception {

		logger.info("editToDoItem service called!!!--------------");
		AjaxResponseBody  result = new AjaxResponseBody ();
		ToDoItem toDoItemResponse = autoGeneralService.editToDoItem(id);
		//If error, just return a 404 Not Found, along with the error message
        if (toDoItemResponse == null) {

			// get all errors  
        	return (ResponseEntity<AjaxResponseBody>) ResponseEntity.notFound();
           
            //return ResponseEntity.notFound(result);

        }
       
		result.setResult(toDoItemResponse);
		return ResponseEntity.ok(result);		
	   
	}

}
