package com.autogeneral.api.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.autogeneral.api.model.AjaxResponseBody;
import com.autogeneral.api.model.AuthTokenInfo;
import com.autogeneral.api.model.ToDoItem;
import com.google.gson.Gson;

/**
 * AutoGeneralIntegrationTestController - This class acts as a controller for integration testing
 * 
 * @author Bindhya Maya
 * Version 1.0
 * Created Date 02/10/2018
 */
@RestController
@RequestMapping("/integrationTest")
public class AutoGeneralIntegrationTestController {
	
	private static final Logger logger = LoggerFactory.getLogger(AutoGeneralIntegrationTestController.class);

	public static final String REST_SERVICE_URI = "http://localhost:8080/";

	public static final String AUTH_SERVER_URI = "http://localhost:8080/autogeneral/oauth/token";

	public static final String QPM_PASSWORD_GRANT = "?grant_type=password&username=autogeneral&password=autogeneral123";

	public static final String QPM_ACCESS_TOKEN = "?access_token=";
	
	private int counter = 0;

	/**
	 * Prepare HTTP Headers.
	 * @return HttpHeaders
	 */
	private static HttpHeaders getHeaders() {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		return headers;
	}

	/**
	 * Add HTTP Authorization header, using Basic-Authentication to send
	 * client-credentials.
	 * @return HttpHeaders
	 */
	private static HttpHeaders getHeadersWithClientCredentials() {
		String plainClientCredentials = "my-trusted-client:secret";
		String base64ClientCredentials = new String(Base64.encodeBase64(plainClientCredentials.getBytes()));

		HttpHeaders headers = getHeaders();
		headers.add("Authorization", "Basic " + base64ClientCredentials);
		return headers;
	}

	/**
	 * Send a POST request [on /oauth/token] to get an access-token, which will then
	 * be send with each request.
	 * @return AuthTokenInfo
	 */
	@SuppressWarnings({ "unchecked" })
	public static AuthTokenInfo sendTokenRequest() {
		RestTemplate restTemplate = new RestTemplate();

		HttpEntity<String> request = new HttpEntity<String>(getHeadersWithClientCredentials());
		ResponseEntity<Object> response = restTemplate.exchange(AUTH_SERVER_URI + QPM_PASSWORD_GRANT, HttpMethod.POST,
				request, Object.class);
		LinkedHashMap<String, Object> map = (LinkedHashMap<String, Object>) response.getBody();
		AuthTokenInfo tokenInfo = null;

		if (map != null) {
			tokenInfo = new AuthTokenInfo();
			tokenInfo.setAccess_token((String) map.get("access_token"));
			tokenInfo.setToken_type((String) map.get("token_type"));
			tokenInfo.setRefresh_token((String) map.get("refresh_token"));
			tokenInfo.setExpires_in((int) map.get("expires_in"));
			tokenInfo.setScope((String) map.get("scope"));
			logger.debug("access_token =" + map.get("access_token") + ", token_type=" + map.get("token_type")
					+ ", refresh_token=" + map.get("refresh_token") + ", expires_in=" + map.get("expires_in")
					+ ", scope=" + map.get("scope"));
		} else {
			logger.info("No Token exist----------");

		}
		return tokenInfo;
	}

	/**
	 * integrationTest method tests all the endpoints
	 * @param apiUrl
	 * @return String
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET)
	public String integrationTest1(@RequestParam("apiUrl") String apiUrl) throws Exception {
	
		return testAPI(apiUrl);
		
	}
	
	/**
	 * testAPI is the method invoking the api endpoints
	 * @param apiUrl
	 * @return String
	 * @throws Exception
	 */
	private String testAPI(String apiUrl) throws Exception {
		
		
		List<AjaxResponseBody> finalLst = new ArrayList<AjaxResponseBody>();
		AuthTokenInfo createAuthTokenInfo = sendTokenRequest();
		Assert.notNull("Authenticate first please......");

		logger.info("\nTesting CreateToDoItem API started!!!");
		RestTemplate createRestTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		//create new TODO
		HttpEntity<Object> request = new HttpEntity<Object>(createToDoItemVO(), getHeaders());
		ResponseEntity<AjaxResponseBody> responseCreate = createRestTemplate.exchange(
				apiUrl + "/todo" + QPM_ACCESS_TOKEN + createAuthTokenInfo.getAccess_token(),
				HttpMethod.POST, request, AjaxResponseBody.class);
		logger.info("\n TODOItem has been created and the testcase has been successfully completed!!!");
		AjaxResponseBody responseCreateBody = responseCreate.getBody();
		responseCreateBody.setMsg("Create New TODO : toDOItem created successfully");
		finalLst.add(responseCreateBody);
		
		//edit existing TODO
		RestTemplate editRestTemplate = new RestTemplate();
		HttpEntity<Object> requestEditHeader = new HttpEntity<Object>(getHeaders());
		String requestParam = "&id=1";
		ResponseEntity<AjaxResponseBody> responseEdit = editRestTemplate
				.exchange(
						apiUrl + "/todo/" + QPM_ACCESS_TOKEN
								+ createAuthTokenInfo.getAccess_token() + requestParam,
						HttpMethod.PUT, requestEditHeader, AjaxResponseBody.class);	
		AjaxResponseBody responseEditBody = responseEdit.getBody();
		responseEditBody.setMsg("Edit ToDo : toDOItem edited successfully");
		finalLst.add(responseEditBody);
		
		//view TODO
		RestTemplate viewRestTemplate = new RestTemplate();
		HttpEntity<Object> requestViewHeader = new HttpEntity<Object>(getHeaders());
		String requestParamView = "&id=1";
		ResponseEntity<AjaxResponseBody> responseView = viewRestTemplate
				.exchange(
						apiUrl + "/todo/" + QPM_ACCESS_TOKEN
								+ createAuthTokenInfo.getAccess_token() + requestParamView,
						HttpMethod.GET, requestViewHeader, AjaxResponseBody.class);	
		AjaxResponseBody responseViewBody = responseView.getBody();
		responseViewBody.setMsg("View ToDo : toDOItem view successfully");
		finalLst.add(responseViewBody);
		
		//deserialize the result
		String json = new Gson().toJson(finalLst);
		return json;

	}	
	
	/**
	 * method to construct test data object for testing the new ToDoItem 
	 *  
	 * @return ToDoItemVO
	 */
	private ToDoItem createToDoItemVO() {
		ToDoItem toDoItemVO = new ToDoItem();
		toDoItemVO.setCompleted(true);
		toDoItemVO.setText("new TO DO Item Created through IntegrationTest"+ counter++);
		toDoItemVO.setCreatedAt("2017-10-15T23:04:44.082Z");
		return toDoItemVO;
	}


}
