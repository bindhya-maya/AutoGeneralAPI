package com.autogeneral.api.bo.impl;

import java.util.Stack;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.autogeneral.api.bo.AutoGeneralBO;
import com.autogeneral.api.dao.ToDoItemRepository;
import com.autogeneral.api.model.ToDoItem;

/**
 * This class is used as a business logic to to support the rest services. the
 * methods are making the calls to Repository interfaces
 * 
 * @author Bindhya Maya Version 1.0 Created Date 02/10/2018
 */

@Component("autoGeneralBO")
public class AutoGeneralBOImpl implements AutoGeneralBO {
	private static final Logger logger = LoggerFactory
			.getLogger(AutoGeneralBOImpl.class);

	@Autowired
	ToDoItemRepository toDoItemRepository;

	/**
	 * createToDoItem - Calls the repository to create a new ToDoItem
	 * 
	 * @param ToDoItem
	 * @return ToDoItem
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public ToDoItem createToDoItem(ToDoItem toDoItem) throws Exception {
		ToDoItem toDoItemResponse = null;

		if (toDoItem != null) {
			toDoItemResponse = toDoItemRepository
					.save(toDoItem);
		}
		logger.info("\nCreating new ToDoItem was successfull");
		return toDoItemResponse;
	}

	/**
	 * viewToDoItem - Call repository to View ToDoItem
	 * 
	 * @param id
	 * @return ToDoItem
	 */
	@Transactional(propagation = Propagation.SUPPORTS)
	@Override
	public ToDoItem viewToDoItem(Long id) throws Exception {
		ToDoItem toDoItemResponse = toDoItemRepository.findOne(id);

		logger.info("\n viewToDoItem was successfull");
		return toDoItemResponse;
	}

	/**
	 * editToDoItem - Calls the repository to edit an existing ToDoItem
	 * 
	 * @param id
	 * @return ToDoItem
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	@Override
	public ToDoItem editToDoItem(Long id) throws Exception {
		ToDoItem existingToDoItem = null;

		// get ToDoItem
		existingToDoItem = toDoItemRepository.findOne(id);

		if (existingToDoItem != null) {
			existingToDoItem.setText("This is an edited text");
			// save after editing
			toDoItemRepository.save(existingToDoItem);
			logger.info("\n editToDoItem was successfull");
		}
		
		return existingToDoItem;
	}


	/**
	 * validateBrackets method determine if a string of bracket is valid or
	 * invalid Every opening bracket has a corresponding closing bracket. The
	 * closing bracket of a pair must be of the same as the opening bracket,
	 * e.g. () is valid, but [) is not valid.
	 * 
	 * @param inputString
	 * @return Boolean
	 * @throws Exception
	 */
	@Override
	public String validateBrackets(String inputString) throws Exception {
		Stack<Character> stack = new Stack<>();

		for (int i = 0; i < inputString.length(); i++) {
			if (inputString.charAt(i) == '{' || inputString.charAt(i) == '['
					|| inputString.charAt(i) == '(') {
				stack.push(inputString.charAt(i));
			} else if (inputString.charAt(i) == '}'
					|| inputString.charAt(i) == ']'
					|| inputString.charAt(i) == ')') {
				if (stack.size() == 0)
					return formResult(inputString, false);
				switch (stack.pop()) {
				case '(':
					if (inputString.charAt(i) != ')')
						return formResult(inputString, false);
					break;
				case '[':
					if (inputString.charAt(i) != ']')
						return formResult(inputString, false);
					break;
				case '{':
					if (inputString.charAt(i) != '}')
						return formResult(inputString, false);
					break;
				}
			}
		}
		return formResult(inputString, stack.size() == 0);
	}

	/**
	 * formResult forms the validateBrackets result back to client
	 * 
	 * @param input
	 * @param flag
	 * @return String
	 */
	private String formResult(String input, boolean flag) {
		String result = "{\n" + "input: " + input + ",\n" + "isBalanced: "
				+ flag + "\n}";
		return result;

	}
}
