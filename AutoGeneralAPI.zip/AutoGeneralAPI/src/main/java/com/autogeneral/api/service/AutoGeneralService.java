package com.autogeneral.api.service;

import com.autogeneral.api.model.ToDoItem;

/**
 * AutoGeneralService - is the interface which have the bracket validation service defined in
 * its implementation
 * 
 * @author Bindhya Maya
 * Version 1.0
 * Created Date 02/10/2018
 */
public interface AutoGeneralService {

	/**
	 * createToDoItem - creates a new ToDoItem
	 * 
	 * @param ToDoItem
	 * @return ToDoItem
	 */
	public ToDoItem createToDoItem(ToDoItem toDoItem) throws Exception;
	
	/**
	 * viewToDoItem - View a particular ToDoItem
	 * @param id
	 * @return ToDoItem
	 */
	public ToDoItem viewToDoItem(Long id) throws Exception;

	/**
	 * editToDoItem - to edit a ToDoItem
	 * 
	 * @param id
	 * @return ToDoItem
	 */
	public ToDoItem editToDoItem(Long id) throws Exception;
	
	/**
	 * validateBrackets - validates brackets from an input string
	 * 
	 * @param inputString
	 * @return String
	 */
	public String validateBrackets(String inputString) throws Exception;

}
