package com.autogeneral.api;

import javax.annotation.PostConstruct;

import org.hsqldb.util.DatabaseManagerSwing;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * AutoGeneralApplication - This class is an entry point of spring boot application
 * The end points are secured with oAuth2 tokenization.
 * 
 * @author Bindhya Maya
 * Version 1.0
 * Created Date 02/10/2018
 */


@SpringBootApplication
@EntityScan(basePackages = "com.autogeneral.api.model")
@EnableJpaRepositories(basePackages = "com.autogeneral.api.dao")
public class AutoGeneralApplication {
	
	private static final Logger logger = LoggerFactory.getLogger(AutoGeneralApplication.class);

	/**
	 * The main() method uses Spring Boot’s SpringApplication.run() method to launch
	 * an application. This main() method starts up the Spring ApplicationContext
	 * 
	 * @param :
	 *            args to set system level arguments
	 * @param args
	 */
	public static void main(String[] args) {
		logger.info("--Application Is Starting Up--");
		SpringApplicationBuilder builder = new SpringApplicationBuilder(AutoGeneralApplication.class);
		builder.headless(false);
		builder.run(args);
	}

	/**
	 * Swing component to get the HSQL database manager run component The DB
	 * explorer will open automatically when the application is up
	 */
	@PostConstruct
	public void getDbManager() {
		DatabaseManagerSwing.main(new String[] { "--url", "jdbc:hsqldb:mem:testdb", "--user", "sa", "--password", "" });
	}

	/**
	 * default constructor
	 */
	public AutoGeneralApplication() {
		
	}

}
