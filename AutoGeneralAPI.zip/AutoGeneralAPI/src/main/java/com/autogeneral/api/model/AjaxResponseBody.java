package com.autogeneral.api.model;
public class AjaxResponseBody {

	    String msg;
	    public String getMsg() {
			return msg;
		}
		public void setMsg(String msg) {
			this.msg = msg;
		}
		public ToDoItem getResult() {
			return result;
		}
		public void setResult(ToDoItem result) {
			this.result = result;
		}
		ToDoItem result;

	    //getters and setters

	
}
