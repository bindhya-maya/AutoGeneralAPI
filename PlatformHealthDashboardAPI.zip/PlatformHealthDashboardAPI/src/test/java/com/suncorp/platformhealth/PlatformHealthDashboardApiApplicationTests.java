package com.suncorp.platformhealth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlatformHealthDashboardApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
