package com.suncorp.platformhealth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlatformHealthDashboardApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlatformHealthDashboardApiApplication.class, args);
	}

}
